<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<meta name="apple-mobile-web-app-capable" content="yes" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="format-detection" content="telephone=no" />
		<title>Page not found &#8211; Prague</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//www.youtube.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Prague &raquo; Feed" href="https://prague.foxthemes.me/feed/" />
<link rel="alternate" type="application/rss+xml" title="Prague &raquo; Comments Feed" href="https://prague.foxthemes.me/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/prague.foxthemes.me\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='formidable-css'  href='https://prague.foxthemes.me/wp-content/plugins/formidable/css/formidableforms.css?ver=92638' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://prague.foxthemes.me/wp-includes/css/dist/block-library/style.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='https://prague.foxthemes.me/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=3.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://prague.foxthemes.me/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=3.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://prague.foxthemes.me/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.8' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='https://prague.foxthemes.me/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=4.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='https://prague.foxthemes.me/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=4.4.1' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='https://prague.foxthemes.me/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=4.4.1' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='swiper-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/swiper.min.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/slick.min.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='owl-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/owlcarousel.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/magnific-popup.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='prague-fonts-css'  href='//fonts.googleapis.com/css?family=Roboto%3A400%2C100%2C300%2C500%2C700%26subset%3Dlatin%2Clatin-ext&#038;ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='prague-core-css-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/style.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesomes-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/font-awesome.min.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='ionicons-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/ionicons.min.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='et-line-font-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/et-line-font.css?ver=2.3.1' type='text/css' media='all' />
<style id='et-line-font-inline-css' type='text/css'>
[data-icon]:before {content:none} .ui-dialog{position:fixed;top:100px;}
</style>
<link rel='stylesheet' id='prague-before-after-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/before-after.min.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/bootstrap.min.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='prague-unit-test-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/unit-test.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='prague-theme-css-css'  href='https://prague.foxthemes.me/wp-content/themes/prague/assets/css/style.min.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='prague-dynamic-css-css'  href='https://prague.foxthemes.me/wp-admin/admin-ajax.php?action=prague_dynamic_css&#038;ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='the-grid-css'  href='https://prague.foxthemes.me/wp-content/plugins/the-grid/frontend/assets/css/the-grid.min.css?ver=2.7.1' type='text/css' media='all' />
<style id='the-grid-inline-css' type='text/css'>
.tolb-holder{background:rgba(0,0,0,0.8)}.tolb-holder .tolb-close,.tolb-holder .tolb-title,.tolb-holder .tolb-counter,.tolb-holder .tolb-next i,.tolb-holder .tolb-prev i{color:#ffffff}.tolb-holder .tolb-load{border-color:rgba(255,255,255,0.2);border-left:3px solid #ffffff}
.to-heart-icon,.to-heart-icon svg,.to-post-like,.to-post-like .to-like-count{position:relative;display:inline-block}.to-post-like{width:auto;cursor:pointer;font-weight:400}.to-heart-icon{float:left;margin:0 4px 0 0}.to-heart-icon svg{overflow:visible;width:15px;height:14px}.to-heart-icon g{-webkit-transform:scale(1);transform:scale(1)}.to-heart-icon path{-webkit-transform:scale(1);transform:scale(1);transition:fill .4s ease,stroke .4s ease}.no-liked .to-heart-icon path{fill:#999;stroke:#999}.empty-heart .to-heart-icon path{fill:transparent!important;stroke:#999}.liked .to-heart-icon path,.to-heart-icon svg:hover path{fill:#ff6863!important;stroke:#ff6863!important}@keyframes heartBeat{0%{transform:scale(1)}20%{transform:scale(.8)}30%{transform:scale(.95)}45%{transform:scale(.75)}50%{transform:scale(.85)}100%{transform:scale(.9)}}@-webkit-keyframes heartBeat{0%,100%,50%{-webkit-transform:scale(1)}20%{-webkit-transform:scale(.8)}30%{-webkit-transform:scale(.95)}45%{-webkit-transform:scale(.75)}}.heart-pulse g{-webkit-animation-name:heartBeat;animation-name:heartBeat;-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-iteration-count:infinite;animation-iteration-count:infinite;-webkit-transform-origin:50% 50%;transform-origin:50% 50%}.to-post-like a{color:inherit!important;fill:inherit!important;stroke:inherit!important}
</style>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.8' id='tp-tools-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.8' id='revmin-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/prague.foxthemes.me\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=4.4.1' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=5.7' id='vc_woocommerce-add-to-cart-js-js'></script>
<link rel="https://api.w.org/" href="https://prague.foxthemes.me/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://prague.foxthemes.me/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://prague.foxthemes.me/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.2" />
<meta name="generator" content="WooCommerce 4.4.1" />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://prague.foxthemes.me/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.8 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script>
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>
  </head>
<body class="error404 theme-prague woocommerce-no-js  wpb-js-composer js-comp-ver-5.7 vc_responsive" data-scrollbar="">

			<div class="prague-loader">
			<div class="prague-loader-wrapper">

				                    <div class="prague-loader-bar">
					    PRAGUE                    </div>
								</div>
			</div>
		</div>
	
	<header class="prague-header  sticky-menu sticky-mobile-menu dark   simple">


        
            <div class="prague-logo">
                <a href="https://prague.foxthemes.me/">
                    <img width="145" height="46" src="https://prague.foxthemes.me/wp-content/uploads/2017/03/logo-dark.png" class="image_logo" alt="" loading="lazy" />                </a>
            </div>

            <div class="prague-header-wrapper">

                <div class="prague-navigation">
                    <div class="pargue-navigation-wrapper">
                        <div class="prague-navigation-inner">

                            
                            <nav>
                                <ul class="main-menu"><li id="menu-item-2317" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2317"><a href="#">Home</a>
<ul class="sub-menu">
	<li id="menu-item-2939" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2939"><a href="#">Part 1</a>
	<ul class="sub-menu">
		<li id="menu-item-2358" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-2358"><a href="https://prague.foxthemes.me/">Main Home</a></li>
		<li id="menu-item-2808" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2808"><a href="https://prague.foxthemes.me/diagonal-slideshow/">Diagonal Slideshow *</a></li>
		<li id="menu-item-2329" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2329"><a href="https://prague.foxthemes.me/minimalist-home/">Minimalist Home</a></li>
		<li id="menu-item-2763" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2763"><a href="https://prague.foxthemes.me/promotions/">Promotions *</a></li>
		<li id="menu-item-2764" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2764"><a href="https://prague.foxthemes.me/showcase/">Showcase *</a></li>
		<li id="menu-item-2342" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2342"><a href="https://prague.foxthemes.me/onepage-home/">OnePage Home</a></li>
		<li id="menu-item-2814" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2814"><a href="https://prague.foxthemes.me/albums-caroosell-2/">Albums Caroosell *</a></li>
		<li id="menu-item-2359" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2359"><a href="https://prague.foxthemes.me/work-film-strip/">Film Strip</a></li>
		<li id="menu-item-2360" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2360"><a href="https://prague.foxthemes.me/work-category-list/">Category List</a></li>
	</ul>
</li>
	<li id="menu-item-2940" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2940"><a href="#">Part 2</a>
	<ul class="sub-menu">
		<li id="menu-item-2787" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2787"><a href="https://prague.foxthemes.me/minimal-slider/">Minimal Slider *</a></li>
		<li id="menu-item-2364" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2364"><a href="https://prague.foxthemes.me/revolution-slider/">Revolution Slider</a></li>
		<li id="menu-item-2796" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2796"><a href="https://prague.foxthemes.me/gallery/">Gallery *</a></li>
		<li id="menu-item-2361" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2361"><a href="https://prague.foxthemes.me/work-timeline-images/">Timeline Projects</a></li>
		<li id="menu-item-2362" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2362"><a href="https://prague.foxthemes.me/creative-banner/">Creative Banner</a></li>
		<li id="menu-item-2363" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2363"><a href="https://prague.foxthemes.me/projects/">Projects</a></li>
		<li id="menu-item-2461" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2461"><a href="https://prague.foxthemes.me/parallax-presentation/">Parallax Presentation</a></li>
		<li id="menu-item-2375" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2375"><a href="https://prague.foxthemes.me/parallax-with-text/">Parallax With Text</a></li>
		<li id="menu-item-2371" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2371"><a href="https://prague.foxthemes.me/simple/">Simple</a></li>
		<li id="menu-item-2366" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2366"><a href="https://prague.foxthemes.me/splitted-screen/">Splitted Screen</a></li>
	</ul>
</li>
	<li id="menu-item-2941" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2941"><a href="#">Part 3</a>
	<ul class="sub-menu">
		<li id="menu-item-2373" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2373"><a href="https://prague.foxthemes.me/splitted-creative-banner/">Splitted Creative Banner</a></li>
		<li id="menu-item-2370" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2370"><a href="https://prague.foxthemes.me/columns-gallery/">Creative gallery</a></li>
		<li id="menu-item-2367" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2367"><a href="https://prague.foxthemes.me/slider/">Slider</a></li>
		<li id="menu-item-2374" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2374"><a href="https://prague.foxthemes.me/before-after/">Before &#038; After</a></li>
		<li id="menu-item-2365" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2365"><a href="https://prague.foxthemes.me/fullscreen-slider/">Fullscreen Slider</a></li>
		<li id="menu-item-2380" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2380"><a href="https://prague.foxthemes.me/video-background/">Video Background</a></li>
		<li id="menu-item-2598" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2598"><a href="https://prague.foxthemes.me/carousel-showcase/">Carousel showcase</a></li>
		<li id="menu-item-2594" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2594"><a href="https://prague.foxthemes.me/interior-design-showcase/">Interior Design Showcase</a></li>
		<li id="menu-item-2614" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2614"><a href="https://prague.foxthemes.me/split-slider/">Split Slider</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-2310" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2310"><a href="#">Pages</a>
<ul class="sub-menu">
	<li id="menu-item-2313" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2313"><a href="#">About</a>
	<ul class="sub-menu">
		<li id="menu-item-2331" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2331"><a href="https://prague.foxthemes.me/about-me/">About Me</a></li>
		<li id="menu-item-2330" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2330"><a href="https://prague.foxthemes.me/about-us/">About Us</a></li>
		<li id="menu-item-2357" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2357"><a href="https://prague.foxthemes.me/work-process/">Work Process</a></li>
	</ul>
</li>
	<li id="menu-item-2336" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-2336"><a href="https://prague.foxthemes.me/services/">Services</a>
	<ul class="sub-menu">
		<li id="menu-item-2345" class="menu-item menu-item-type-post_type menu-item-object-services menu-item-2345"><a href="https://prague.foxthemes.me/services-item/planning/">Services Details</a></li>
	</ul>
</li>
	<li id="menu-item-2335" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2335"><a href="https://prague.foxthemes.me/bibliography/">Bibliography</a></li>
	<li id="menu-item-2368" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2368"><a href="https://prague.foxthemes.me/media/">Media</a></li>
	<li id="menu-item-2343" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2343"><a href="https://prague.foxthemes.me/exhibition/">Exhibition</a></li>
	<li id="menu-item-2339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2339"><a href="https://prague.foxthemes.me/clients/">Clients</a></li>
	<li id="menu-item-2314" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2314"><a href="#">Pricing</a>
	<ul class="sub-menu">
		<li id="menu-item-2337" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2337"><a href="https://prague.foxthemes.me/pricing-image/">Pricing Image</a></li>
		<li id="menu-item-2338" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2338"><a href="https://prague.foxthemes.me/pricing-simple/">Pricing Simple</a></li>
	</ul>
</li>
	<li id="menu-item-2315" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2315"><a href="#">Contact</a>
	<ul class="sub-menu">
		<li id="menu-item-2341" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2341"><a href="https://prague.foxthemes.me/contact-me/">Contact Me</a></li>
		<li id="menu-item-2340" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2340"><a href="https://prague.foxthemes.me/contact-us/">Contact Us</a></li>
	</ul>
</li>
	<li id="menu-item-2318" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2318"><a href="#">Other Pages</a>
	<ul class="sub-menu">
		<li id="menu-item-2344" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2344"><a href="https://prague.foxthemes.me/coming-soon/">Coming Soon</a></li>
		<li id="menu-item-2346" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2346"><a href="https://prague.foxthemes.me/protected-page/">Protected Page</a></li>
		<li id="menu-item-2312" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2312"><a href="https://prague.foxthemes.me/404">Error Page</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-2311" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2311"><a href="#">Projects</a>
<ul class="sub-menu">
	<li id="menu-item-2355" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2355"><a href="https://prague.foxthemes.me/work-list/">Work List</a></li>
	<li id="menu-item-2333" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2333"><a href="https://prague.foxthemes.me/work-grid/">Work Grid</a></li>
	<li id="menu-item-2334" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2334"><a href="https://prague.foxthemes.me/work-masonry/">Work Masonry</a></li>
	<li id="menu-item-2332" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2332"><a href="https://prague.foxthemes.me/work-film-strip/">Work Film Strip</a></li>
	<li id="menu-item-2356" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2356"><a href="https://prague.foxthemes.me/work-category-list/">Work Category List</a></li>
	<li id="menu-item-2348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2348"><a href="https://prague.foxthemes.me/work-timeline-list/">Work Timeline List</a></li>
	<li id="menu-item-2347" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2347"><a href="https://prague.foxthemes.me/work-timeline-images/">Work Timeline Images</a></li>
	<li id="menu-item-2588" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2588"><a href="https://prague.foxthemes.me/work-pinterest/">Work Pinterest</a></li>
	<li id="menu-item-2589" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2589"><a href="https://prague.foxthemes.me/fullscreen-projects/">Work Fullscreen</a></li>
</ul>
</li>
<li id="menu-item-2316" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2316"><a href="#">Project Details</a>
<ul class="sub-menu">
	<li id="menu-item-2351" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-2351"><a href="https://prague.foxthemes.me/projects-item/daniel-moore-appartaments/">Parallax</a></li>
	<li id="menu-item-2353" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-2353"><a href="https://prague.foxthemes.me/projects-item/pastel-tones-design/">Parallax With Text</a></li>
	<li id="menu-item-2377" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-2377"><a href="https://prague.foxthemes.me/projects-item/henders-tragers-villa/">Simple</a></li>
	<li id="menu-item-2486" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-2486"><a href="https://prague.foxthemes.me/projects-item/stone-krow-house/">Splitted Screen</a></li>
	<li id="menu-item-2379" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-2379"><a href="https://prague.foxthemes.me/projects-item/mountain-house/">Splitted Creative Banner</a></li>
	<li id="menu-item-2354" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-2354"><a href="https://prague.foxthemes.me/projects-item/tycoon-office-interior-design/">Columns Gallery</a></li>
	<li id="menu-item-2349" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-2349"><a href="https://prague.foxthemes.me/projects-item/alto-furniture/">Slider</a></li>
	<li id="menu-item-2350" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-2350"><a href="https://prague.foxthemes.me/projects-item/alto-furniture-2/">Before &#038; After</a></li>
	<li id="menu-item-2352" class="menu-item menu-item-type-post_type menu-item-object-projects menu-item-2352"><a href="https://prague.foxthemes.me/projects-item/luxurious-apartment/">Fullscreen Slider</a></li>
</ul>
</li>
<li id="menu-item-2433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-2433"><a href="https://prague.foxthemes.me/shop/">Shop</a>
<ul class="sub-menu">
	<li id="menu-item-2436" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-2436"><a href="https://prague.foxthemes.me/product/soft-chair/">Product Details</a></li>
</ul>
</li>
<li id="menu-item-2445" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-has-children menu-item-2445"><a href="https://prague.foxthemes.me/blog/">Blog</a>
<ul class="sub-menu">
	<li id="menu-item-2446" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2446"><a href="https://prague.foxthemes.me/blog-list/">Blog List</a></li>
	<li id="menu-item-2447" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-2447"><a href="https://prague.foxthemes.me/time-inc-architectura/">Blog Details</a></li>
</ul>
</li>
</ul>                            </nav>

                        </div>
                    </div>
                </div>

                
                <!-- mobile icon -->
                <div class="prague-nav-menu-icon">
                    <a href="#">
                        <i></i>
                    </a>
                </div>


                		<div class="prague-social-nav">

						<a href="#">
				<i class="fa fa-chain-broken" aria-hidden="true"></i>
			</a>
						
			<ul class="social-content">
											<li>
					<a target="_blank" href="https://www.behance.net/foxthemes">
						<i aria-hidden="true" class="fa fa-behance"></i>
					</a>
				</li>
															<li>
					<a target="_blank" href="https://twitter.com/foxthemes_offic">
						<i aria-hidden="true" class="fa fa-twitter"></i>
					</a>
				</li>
															<li>
					<a target="_blank" href="https://www.facebook.com/foxthemes.page/">
						<i aria-hidden="true" class="fa fa-facebook"></i>
					</a>
				</li>
															<li>
					<a target="_blank" href="https://www.pinterest.com/foxthemes/">
						<i aria-hidden="true" class="fa fa-pinterest-p"></i>
					</a>
				</li>
										</ul>

		</div>
		
            </div>

        

		
	</header>
	<!-- END HEADER -->
<div class="container padd-only-xs">
	<div class="row">
		<div class="col-xs-12">
			<div class="page-calculate fullheight">
				<div class="page-calculate-content">
					<section class="prague-error-wrapper">
												<div class="prague-error-img">
							<img class="s-img-switch" src="https://prague.foxthemes.me/wp-content/uploads/2017/02/error.png">
						</div>
						 
						<div class="prague-error-content">
							
							<div class="prague-svg-animation-text">
								<?xml version="1.0"?>
<svg width="100%" height="100%" style="" fill="transparent" viewBox="0 0 173.73046875 129.921875" preserveAspectRatio="xMidYMid meet" class="prague-svg"><path d=" M2.83203125,94.775390625l28.515625-45.80078125l0-0.146484375l16.50390625,0l0,43.310546875l7.177734375,0l0,12.79296875l-7.177734375,0l0,14.990234375l-16.50390625,0l0-14.990234375l-27.5390625,0z M17.578125,92.138671875l13.76953125,0l0-21.875l-0.29296875-0.09765625l-1.26953125,2.001953125z"/><path d=" M62.109375,91.845703125l0-14.94140625q0-14.404296875,6.640625-21.7529296875t18.06640625-7.3486328125q11.376953125,0,18.0908203125,7.373046875t6.7138671875,21.728515625l0,14.94140625q0,14.404296875-6.689453125,21.7529296875t-18.017578125,7.3486328125q-11.42578125,0-18.115234375-7.3486328125t-6.689453125-21.7529296875z M78.564453125,92.87109375q0,8.30078125,2.099609375,11.8408203125t6.25,3.5400390625q4.052734375,0,6.15234375-3.5400390625t2.099609375-11.8408203125l0-17.08984375q0-8.154296875-2.1484375-11.71875t-6.201171875-3.564453125q-4.1015625,0-6.1767578125,3.564453125t-2.0751953125,11.71875l0,17.08984375z"/><path d=" M118.65234375,94.775390625l28.515625-45.80078125l0-0.146484375l16.50390625,0l0,43.310546875l7.177734375,0l0,12.79296875l-7.177734375,0l0,14.990234375l-16.50390625,0l0-14.990234375l-27.5390625,0z M133.3984375,92.138671875l13.76953125,0l0-21.875l-0.29296875-0.09765625l-1.26953125,2.001953125z"/></svg>
							</div>

														<div class="error-subtitle">
								PAGE ERROR							</div>
							 
						
															<h2 class="error-title">
									Architecture crashed :(								</h2>
							
						</div>
						
													<a href="https://prague.foxthemes.me/" class="error-btn a-btn-2 creative">
								<span class="a-btn-line"></span>
								TAKE ME HOME							</a>
						 
					</section>
				</div>
			</div>
		</div>
	</div>
</div>


	<!-- START FOOTER -->
	<footer class="prague-footer default">

					<img width="2500" height="1248" src="https://prague.foxthemes.me/wp-content/uploads/2017/03/ffa51a33625455.56b20f01c3608.jpg" class="s-img-switch" alt="" loading="lazy" srcset="https://prague.foxthemes.me/wp-content/uploads/2017/03/ffa51a33625455.56b20f01c3608.jpg 2500w, https://prague.foxthemes.me/wp-content/uploads/2017/03/ffa51a33625455.56b20f01c3608-300x150.jpg 300w, https://prague.foxthemes.me/wp-content/uploads/2017/03/ffa51a33625455.56b20f01c3608-768x383.jpg 768w, https://prague.foxthemes.me/wp-content/uploads/2017/03/ffa51a33625455.56b20f01c3608-1024x511.jpg 1024w" sizes="(max-width: 2500px) 100vw, 2500px" />
			<div class="footer-content-outer">

									<div class="footer-top-content">
						<div class="prague-footer-main-block">

									<div class="prague-logo">
			<a href="https://prague.foxthemes.me/">
				<img width="145" height="46" src="https://prague.foxthemes.me/wp-content/uploads/2017/03/logo-white.png" class="attachment-full size-full" alt="" loading="lazy" />			</a>
		</div>
		
															<div class="footer-main-content">
									<p>The company principle of Architecture-Studio is the collective conception. From the very beginning, the practice has believed in the virtues of exchange, crossing ideas, common effort, shared knowledge and enthusiasm.</p>
								</div>
							
						</div>
						<div class="prague-footer-info-block">

															<h6 class="footer-info-block-title">GET IN TOUCH</h6>
							
															<div class="footer-info-block-content">
									<p><a href="tel:+7(885)5896985">+7 (885) 589 69 85</a></p>
<p><a href="/cdn-cgi/l/email-protection#f6868497918393db9784959e9f8293958285b69f989099d895999b"><span class="__cf_email__" data-cfemail="83f3f1e2e4f6e6aee2f1e0ebeaf7e6e0f7f0c3eaede5ecade0ecee">[email&#160;protected]</span></a></p>
<p>Litačka, Jungmannova 35/29, Nové Město,Czech Republic</p>
								</div>
							
						</div>
					</div>
								<div class="footer-bottom-content">

					<!-- Footer copyright -->
											<div class="footer-copyright">
							<p>PRAGUE (C) 2019 ALL RIGHTS RESERVED</p>
						</div>
										<!-- End footer copyright -->

							<div class="prague-social-nav">

						
			<ul class="social-content">
											<li>
					<a target="_blank" href="https://www.behance.net/foxthemes">
						<i aria-hidden="true" class="fa fa-behance"></i>
					</a>
				</li>
															<li>
					<a target="_blank" href="https://twitter.com/foxthemes_offic">
						<i aria-hidden="true" class="fa fa-twitter"></i>
					</a>
				</li>
															<li>
					<a target="_blank" href="https://www.facebook.com/foxthemes.page/">
						<i aria-hidden="true" class="fa fa-facebook"></i>
					</a>
				</li>
															<li>
					<a target="_blank" href="https://www.pinterest.com/foxthemes/">
						<i aria-hidden="true" class="fa fa-pinterest-p"></i>
					</a>
				</li>
										</ul>

		</div>
		
				</div>
			</div>
		


		
	</footer>

	

	<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=4.4.1' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_68307c5bbc9cb467a778c8501c2fec51","fragment_name":"wc_fragments_68307c5bbc9cb467a778c8501c2fec51","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=4.4.1' id='wc-cart-fragments-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/swiper.min.js?ver=2.3.1' id='swiper-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/file_picker.js?ver=2.3.1' id='file-picker-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=5.7' id='isotope-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/tweenMax.min.js?ver=2.3.1' id='tweenMax-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/vivus.min.js?ver=2.3.1' id='prague-vivus-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/slick.min.js?ver=2.3.1' id='slick-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/jquery.magnific-popup.min.js?ver=2.3.1' id='magnific-popup-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/hammer.min.js?ver=2.3.1' id='hammer-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/foxlazy.min.js?ver=2.3.1' id='prague-foxlazy-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/all.js?ver=2.3.1' id='prague-theme-js-js'></script>
<script type='text/javascript' id='prague-theme-js-js-after'>
/*const CURRENT_THEME_ID = 19618927;
const FILES_URL = 'http://w4.themedemo.co/envato-iframe';
	const HIRE_URL = 'https://wcopilot.com/'; // tut mojesh minyaty link
const body = document.body;
	const script = document.createElement('script');
	script.type = 'text/javascript';
	script.src = `${FILES_URL}/envato-bar.js?v=4`;
	script.async = true;

	body.appendChild(script);*/
</script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/kenburn.js?ver=2.3.1' id='prague-kenburn-js-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/jquery.multiscroll.js?ver=2.3.1' id='prague-multiscroll-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/countTo.js?ver=2.3.1' id='prague-countT-js-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/skills.js?ver=2.3.1' id='prague-skills-js-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/parallax.min.js?ver=2.3.1' id='prague-parallax-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/owlcarousel.js?ver=2.3.1' id='prague-owlcarousel-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/split-slider.js?ver=2.3.1' id='prague-split-slider-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/banner_slider.js?ver=2.3.1' id='prague-banner-slider-js'></script>
<script type='text/javascript' src='https://www.youtube.com/iframe_api?ver=2.3.1' id='prague-youtube-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/wow.min.js?ver=2.3.1' id='prague-wow-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/themes/prague/assets/js/before-after.min.js?ver=2.3.1' id='prague-before-after-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-includes/js/jquery/ui/effect.min.js?ver=1.12.1' id='jquery-effects-core-js'></script>
<script type='text/javascript' id='the-grid-js-extra'>
/* <![CDATA[ */
var tg_global_var = {"url":"https:\/\/prague.foxthemes.me\/wp-admin\/admin-ajax.php","nonce":"ba7fb5299f","is_mobile":null,"mediaelement":"","mediaelement_ex":null,"lightbox_autoplay":"","debounce":"","meta_data":null,"main_query":{"attachment":"flipbook-js","error":"","m":"","p":0,"post_parent":"","subpost":"","subpost_id":"","attachment_id":0,"name":"flipbook-js","pagename":"","page_id":0,"second":"","minute":"","hour":"","day":0,"monthnum":0,"year":0,"w":0,"category_name":"","tag":"","cat":"","tag_id":"","author":"","author_name":"","feed":"","tb":"","paged":0,"meta_key":"","meta_value":"","preview":"","s":"","sentence":"","title":"","fields":"","menu_order":"","embed":"","category__in":[],"category__not_in":[],"category__and":[],"post__in":[],"post__not_in":[],"post_name__in":[],"tag__in":[],"tag__not_in":[],"tag__and":[],"tag_slug__in":[],"tag_slug__and":[],"post_parent__in":[],"post_parent__not_in":[],"author__in":[],"author__not_in":[],"ignore_sticky_posts":false,"suppress_filters":false,"cache_results":true,"update_post_term_cache":true,"lazy_load_term_meta":true,"update_post_meta_cache":true,"post_type":"","posts_per_page":8,"nopaging":false,"comments_per_page":"50","no_found_rows":false,"order":"DESC"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-content/plugins/the-grid/frontend/assets/js/the-grid.min.js?ver=2.7.1' id='the-grid-js'></script>
<script type='text/javascript' src='https://prague.foxthemes.me/wp-includes/js/wp-embed.min.js?ver=5.8.2' id='wp-embed-js'></script>
<script type="text/javascript">var to_like_post = {"url":"https://prague.foxthemes.me/wp-admin/admin-ajax.php","nonce":"a251bce26f"};!function(t){"use strict";t(document).ready(function(){t(document).on("click",".to-post-like:not('.to-post-like-unactive')",function(e){e.preventDefault();var o=t(this),n=o.data("post-id"),s=parseInt(o.find(".to-like-count").text());return o.addClass("heart-pulse"),t.ajax({type:"post",url:to_like_post.url,data:{nonce:to_like_post.nonce,action:"to_like_post",post_id:n,like_nb:s},context:o,success:function(e){e&&((o=t(this)).attr("title",e.title),o.find(".to-like-count").text(e.count),o.removeClass(e.remove_class+" heart-pulse").addClass(e.add_class))}}),!1})})}(jQuery);</script></body>
</html>

